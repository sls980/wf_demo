package main

import (
	userinterface "wf_demo/user_interface"
)

func main() {
	// 按行处理用户命令行输入
	userinterface.Run()
}
